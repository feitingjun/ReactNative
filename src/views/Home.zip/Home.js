import React, { Component } from 'react';
import { StyleSheet,View,Text,PanResponder } from 'react-native';
import { Button } from 'antd-mobile';

export default class Page extends Component {
    constructor(props){
        super(props);
        this.state = {

        }
    }
    panResponder = PanResponder.create({
            onStartShouldSetPanResponder: () => true,//申请响应触摸开始事件
            onMoveShouldSetPanResponder: () => true,//申请响应触摸进行中事件
            onPanResponderStart: (e) =>{//手指按下时的事件
                console.log(11111111)
            },
            onPanResponderMove: (e) => {//手指移动时的事件
                
            },
            onPanResponderRelease: (e,gs) => {//触摸完成事件
                
            },
            onPanResponderEnd: (e,gs) => {//组件事件响应结束
                if(gs.dx>150) this.props.screenProps.onDrawer();
            },
            onPanResponderTerminate:()=>{
                console.log(22222222)
            },
            onPanResponderTerminationRequest:(e,gs)=>{

            },
            onShouldBlockNativeResponder:(e,gs)=>{
                return false
            }
        })
    onClick = () => {
        this.props.screenProps.onDrawer();
        
    }
    render() {
        return  <View style={styles.container} {...this.panResponder.panHandlers}>
                    <Text>首页</Text>
                    <Button onClick={this.onClick}>打开</Button>
                </View>
    }
}
const styles = StyleSheet.create({
    container:{
        flex:1,
        backgroundColor:"red"
    }
})
